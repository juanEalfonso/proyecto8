/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package android.ud;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author user
 */
@WebService(serviceName = "MiServidorWeb")
public class MiServidorWeb {
private double Euro; 
public MiServidorWeb(){
         Euro=4302.31;}
    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
    @WebMethod(operationName = "GetEuro")
    public double GetEuro() {
        return Euro;
    }
    
    @WebMethod(operationName = "Cop2Euro")
    public double COP2ERURO(@WebParam(name = "valor") String txt) {
         return Double.parseDouble(txt)/Euro;
    }
    
     @WebMethod(operationName = "Euro2Cop")
    public double EURO2COP(@WebParam(name = "valor") String txt) {
        return Double.parseDouble(txt)*Euro;
    }
    
    
    
    
    
}
