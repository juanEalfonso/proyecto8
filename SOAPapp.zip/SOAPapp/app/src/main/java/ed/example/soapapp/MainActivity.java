package ed.example.soapapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import java.text.DecimalFormat;

import Clases.WebService;

public class MainActivity extends AppCompatActivity {



    private Button miboton;
    private TextView salida;
    private TextView valoreuro;
    private TextView conversion;
    private EditText entrada;
    private RadioButton cambiop;
    private String edittext;
    private String displatext;
    private String displayeuro;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cambiop=findViewById(R.id.radioButton);
        cambiop.setChecked(true);
        entrada=findViewById(R.id.editTextNumberDecimal);
        valoreuro=findViewById(R.id.textView2);
        salida=findViewById(R.id.textView3);
        conversion=findViewById(R.id.textView4);
        miboton=findViewById(R.id.button);
        miboton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                if(entrada.getText().length() !=0 && entrada.getText().toString() !=""
                                )
                                { edittext=entrada.getText().toString();

                              CambioEuroWS task=new CambioEuroWS();
                              task.execute();

                                salida.setVisibility(View.VISIBLE);


                                    if(cambiop.isChecked()){
                                        conversion.setText("EUROS al dia de hoy");}
                                    else{
                                        conversion.setText("PESOS al dia de hoy");
                                    }
                                conversion.setVisibility(View.VISIBLE);
                                }
                            }
                        });



        LLamadoInicialWS capini = new LLamadoInicialWS();
                        capini.execute();
    }



private class LLamadoInicialWS extends AsyncTask<String,Void,Void>{
    @Override
    protected Void doInBackground(String... strings) {
        double temp = WebService.CapturaEuroWS("GetEuro");
        displayeuro =String.valueOf(temp);
        return null;
    }
    @Override
    protected void onPostExecute(Void result) {
        valoreuro.setText(displayeuro);
    }
    @Override
    protected void onPreExecute() {
        valoreuro.setText("comienzo captura recopilando datos");
    }
}


    private class CambioEuroWS extends AsyncTask<String,Void,Void>{
        @Override
        protected Void doInBackground(String... strings) {
            double temp ;
                if(cambiop.isChecked()){
                temp= WebService.CambioEuroWS("Cop2Euro",edittext);
                }
                else{
                    temp= WebService.CambioEuroWS("Euro2Cop",edittext);

                }
//limitando decimales

                temp= Math.round(temp * 100) / 100d;
                displatext= String.valueOf(temp);

                return null;
            }
        @Override
        protected void onPostExecute(Void result) {

            //limitando la cantidad de decimanes

            salida.setText(displatext);
        }
        @Override
        protected void onPreExecute() {
            salida.setText("comienzo cambio recopilando datos");
        }
    }





    private class AsyncCallWS extends AsyncTask<String,Void,Void>{
        @Override
        protected Void doInBackground(String... strings) {
            displatext=WebService.HolaMundoWS("hello",edittext);
            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            salida.setText(displatext);
        }
        @Override
        protected void onPreExecute() {
        }
    }



}