package Clases;

import android.util.Log;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

public class WebService {
  // private static String namespace="http://com.example.ud/";
    private static String namespace= "http://ud.android/";
   // private static String url="http://70c06cad341f.ngrok.io/ServidorSOAP1/MiServicioWeb?WSDL";
    private static String url=
           "http://192.168.0.13:8080/ServicioSOAP/MiServidorWeb?WSDL";
   // http://euroconvert.azurewebsites.net/WebService1.asmx
    //http://euroconvert.azurewebsites.net/WebService1.asmx?WSDL
    private static String SOAP_ACTION = "http://android.ud/";


    public static double CapturaEuroWS(String webMethNAME) {
        double resTxt = 0;
        //no me funciono me toco quemarla en string
        //SoapObject request = new SoapObject(namespace, "GetEuro");
        SoapObject request = new SoapObject("http://ud.android/", webMethNAME);
        Log.e("CON_" , "request : " +request);
        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.setOutputSoapObject(request);
        HttpTransportSE androidhttpTransport = new HttpTransportSE(url);
        try {
            androidhttpTransport.call(SOAP_ACTION + webMethNAME, envelope);
            SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
            resTxt = Double.parseDouble(response.toString());
            Log.e("CON_" , "CapturaEuroWS: " +resTxt );
        }
        catch (Exception ex) {
            ex.printStackTrace();
            Log.e("CON_" , "fail: "+ex );
        }
        return  resTxt;
    }


    public static double CambioEuroWS(String webMethNAME,String valord) {
        double resTxt = 0;
        //no me funciono me toco quemarla en string
        //SoapObject request = new SoapObject(namespace, webMethNAME);
        SoapObject request = new SoapObject("http://ud.android/", webMethNAME);
        request.addProperty("valor",valord);
        SoapSerializationEnvelope envelope = new
                SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.setOutputSoapObject(request);
        HttpTransportSE androidhttpTransport = new HttpTransportSE(url);
        try {
            androidhttpTransport.call(SOAP_ACTION + webMethNAME, envelope);
            SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
            resTxt = Double.parseDouble(response.toString());
            Log.e("CON_" , "CapturaEuroWS: " +resTxt );
        }
        catch (Exception ex) {
            ex.printStackTrace();
            Log.e("CON_" , "fail: "+ex );
        }
        return  resTxt;
    }

    public static String HolaMundoWS(String webMethNAME,String name) {
        String resTxt =null;
        //no me funciono me toco quemarla en string
       // SoapObject request = new SoapObject(namespace, webMethNAME);
        SoapObject request = new SoapObject("http://ud.android/", webMethNAME);
        request.addProperty("name",name);
        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.setOutputSoapObject(request);
        HttpTransportSE androidhttpTransportSE = new HttpTransportSE(url);
        try {
            androidhttpTransportSE.call(SOAP_ACTION + webMethNAME, envelope);
            SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
            resTxt =response.toString();
        }
        catch (Exception ex) {
            ex.printStackTrace();
            resTxt= ex.getMessage();
            Log.e("CON_" , "fail: "+ex );
        }
        return  resTxt;
    }





}

